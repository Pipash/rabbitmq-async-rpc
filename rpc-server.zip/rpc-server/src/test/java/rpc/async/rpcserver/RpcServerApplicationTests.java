package rpc.async.rpcserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RpcServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
